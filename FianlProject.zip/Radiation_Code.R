library(rsample)   # data splitting 
library(ggplot2)   # plotting
library(earth)     # fit MARS models
library(caret)     # automating the tuning process
library(vip)       # variable importance
library(pdp)
set.seed(123)
data <- read.csv("E:/2022SPRING/6289 Machine Learning/Final Project/SolarPrediction.csv")
data=subset(data,select = c(Radiation:Speed))
sample_size <- floor(0.70 * nrow(data))

mydtrain_id <- sample(seq_len(nrow(data)), size = sample_size)
train_data <- data[mydtrain_id, ]
test_data <- data[-mydtrain_id, ]
mars1 <- earth(
  Radiation ~Temperature+Humidity+ Pressure+WindDirection.Degrees.+Speed,
  data =  train_data
)
print(mars1)
summary(mars1)

plot(mars1, which = 1)

#degree=2 
mars2 <- earth(
  Radiation ~Temperature+Humidity+ Pressure+WindDirection.Degrees.+Speed,
  data =  train_data,
  degree = 2
)

# cross validated model
hyper_grid <- expand.grid(
  degree = 1:3, 
  nprune = seq(2, 100, length.out = 10) %>% floor()
)

tuned_mars <- train(
  x = subset(train_data , select =Temperature:Speed),
  y = train_data $Radiation,
  method = "earth",
  metric = "RMSE",
  trControl = trainControl(method = "cv", number = 2),
  tuneGrid = hyper_grid
)

# best model
tuned_mars$bestTune


# plot results
ggplot(tuned_mars)


# multiple regression
set.seed(123)
cv_model1 <- train(
  Radiation ~Temperature+Humidity+ Pressure+WindDirection.Degrees.+Speed, 
  data = train_data, 
  method = "lm",
  metric = "RMSE",
  trControl = trainControl(method = "cv", number = 10),
  preProcess = c("zv", "center", "scale")
)

# principal component regression
set.seed(123)
cv_model2 <- train(
  Radiation ~Temperature+Humidity+ Pressure+WindDirection.Degrees.+Speed, 
  data = train_data, 
  method = "pcr",
  trControl = trainControl(method = "cv", number = 10),
  metric = "RMSE",
  preProcess = c("zv", "center", "scale"),
  tuneLength = 20
)

# partial least squares regression
set.seed(123)
cv_model3 <- train(
  Radiation ~Temperature+Humidity+ Pressure+WindDirection.Degrees.+Speed, 
  data = train_data, 
  method = "pls",
  trControl = trainControl(method = "cv", number = 10),
  metric = "RMSE",
  preProcess = c("zv", "center", "scale"),
  tuneLength = 20
)

# regularized regression
set.seed(123)
cv_model4 <- train(
  Radiation ~Temperature+Humidity+ Pressure+WindDirection.Degrees.+Speed, 
  data = train_data,
  method = "glmnet",
  trControl = trainControl(method = "cv", number = 10),
  metric = "RMSE",
  preProcess = c("zv", "center", "scale"),
  tuneLength = 10
)

p1 <- vip(tuned_mars, num_features = 40, bar = FALSE, value = "gcv") + ggtitle("GCV")
p2 <- vip(tuned_mars, num_features = 40, bar = FALSE, value = "rss") + ggtitle("RSS")

gridExtra::grid.arrange(p1, p2, ncol = 2)
coef(tuned_mars$finalModel)


p1 <- partial(tuned_mars, pred.var = "Temperature", grid.resolution = 10) %>% autoplot()
p2 <- partial(tuned_mars, pred.var = "WindDirection.Degrees.", grid.resolution = 10) %>% autoplot()
p3 <- partial(tuned_mars, pred.var = c("Temperature", "WindDirection.Degrees."), grid.resolution = 10) %>% 
  plotPartial(levelplot = FALSE, zlab = "yhat", drape = TRUE, colorkey = TRUE, screen = list(z = -20, x = -60))

gridExtra::grid.arrange(p1, p2, p3, ncol = 3)

predata=predict(tuned_mars,test_data)
mean((predata-test_data$Radiation)^2)



